from .entrypoint import main

main()